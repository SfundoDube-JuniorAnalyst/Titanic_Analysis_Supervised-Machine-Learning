"""
Titanic Dataset — Supervised Learning Task Breakdown
1. Train/Test Split
2. Linear Regression (predicting Fare) -> RMSE
3. Logistic Regression (predicting Survived) -> Accuracy
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import mean_squared_error, accuracy_score, classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder

pd.set_option("display.width", 120)
sns.set_style("whitegrid")
OUT_DIR = "/mnt/user-data/outputs"

# -----------------------------------------------------------------
# 0. LOAD DATA
# -----------------------------------------------------------------
df = pd.read_csv("/mnt/user-data/uploads/titanic_cleaned.csv")
print("=" * 70)
print("RAW DATA SHAPE:", df.shape)
print(df.isna().sum())

# -----------------------------------------------------------------
# 1. CLEAN / PREPROCESS
# -----------------------------------------------------------------
data = df.copy()

# Fill missing Age with median
data["Age"] = data["Age"].fillna(data["Age"].median())

# Fill missing Embarked with mode
if data["Embarked"].isna().any():
    data["Embarked"] = data["Embarked"].fillna(data["Embarked"].mode()[0])

# Fill missing Fare (if any) with median
data["Fare"] = data["Fare"].fillna(data["Fare"].median())

# Drop columns that aren't useful as numeric predictors
data = data.drop(columns=["PassengerId", "Name", "Cabin", "Ticket"], errors="ignore")

# Encode categorical variables
le_sex = LabelEncoder()
data["Sex"] = le_sex.fit_transform(data["Sex"])  # male=1, female=0 (alphabetical)

le_embarked = LabelEncoder()
data["Embarked"] = le_embarked.fit_transform(data["Embarked"])

print("\nCLEANED DATA SAMPLE:")
print(data.head())
print("\nRemaining nulls:\n", data.isna().sum())

# ===================================================================
# TASK A: LINEAR REGRESSION — Predict Fare
# ===================================================================
print("\n" + "=" * 70)
print("TASK A: LINEAR REGRESSION (Target = Survived)")
print("=" * 70)

X_reg = data.drop(columns=["Survived"])
y_reg = data["Survived"]

X_train_r, X_test_r, y_train_r, y_test_r = train_test_split(
    X_reg, y_reg, test_size=0.2, random_state=42
)

lin_model = LinearRegression()
lin_model.fit(X_train_r, y_train_r)
y_pred_r = lin_model.predict(X_test_r)

rmse = np.sqrt(mean_squared_error(y_test_r, y_pred_r))
print(f"Train size: {X_train_r.shape[0]}, Test size: {X_test_r.shape[0]}")
print(f"RMSE (Survival prediction, 0-1 scale): {rmse:.4f}")
print(f"Predicted values range: [{y_pred_r.min():.2f}, {y_pred_r.max():.2f}] (Linear Regression can go outside 0-1)")

# ===================================================================
# TASK B: LOGISTIC REGRESSION — Predict Survived
# ===================================================================
print("\n" + "=" * 70)
print("TASK B: LOGISTIC REGRESSION (Target = Survived)")
print("=" * 70)

X_clf = data.drop(columns=["Survived"])
y_clf = data["Survived"]

X_train_c, X_test_c, y_train_c, y_test_c = train_test_split(
    X_clf, y_clf, test_size=0.2, random_state=42, stratify=y_clf
)

log_model = LogisticRegression(max_iter=1000)
log_model.fit(X_train_c, y_train_c)
y_pred_c = log_model.predict(X_test_c)

acc = accuracy_score(y_test_c, y_pred_c)
print(f"Train size: {X_train_c.shape[0]}, Test size: {X_test_c.shape[0]}")
print(f"Accuracy (Survival prediction): {acc:.4f} ({acc*100:.2f}%)")
print("\nConfusion Matrix:")
print(confusion_matrix(y_test_c, y_pred_c))
print("\nClassification Report:")
print(classification_report(y_test_c, y_pred_c, target_names=["Died", "Survived"]))

# Feature importance (coefficients) for logistic regression
print("\nLogistic Regression Coefficients (log-odds impact):")
coef_df = pd.DataFrame({
    "Feature": X_clf.columns,
    "Coefficient": log_model.coef_[0]
}).sort_values("Coefficient", key=abs, ascending=False)
print(coef_df.to_string(index=False))

# -----------------------------------------------------------------
# SUMMARY TABLE
# -----------------------------------------------------------------
print("\n" + "=" * 70)
print("SUMMARY")
print("=" * 70)
summary = pd.DataFrame({
    "Model Type": ["Linear Regression", "Logistic Regression"],
    "Target": ["Survived", "Survived"],
    "Evaluation Metric": ["RMSE", "Accuracy Score"],
    "Result": [f"{rmse:.4f}", f"{acc:.4f}"]
})
print(summary.to_string(index=False))

# ===================================================================
# VISUALIZATIONS
# ===================================================================

# --- Chart 1: Actual vs Predicted Survival (Linear Regression) ---
fig, ax = plt.subplots(figsize=(7, 6))
jitter = np.random.normal(0, 0.02, size=len(y_test_r))
ax.scatter(y_test_r + jitter, y_pred_r, alpha=0.5, color="#4C72B0", edgecolor="white", s=50)
ax.axhline(0.5, color="gray", linestyle=":", linewidth=1, label="0.5 decision threshold")
ax.axhline(0, color="red", linestyle="--", linewidth=1)
ax.axhline(1, color="red", linestyle="--", linewidth=1, label="Valid range (0-1)")
ax.set_xlabel("Actual Survived (0 = Died, 1 = Survived, jittered)")
ax.set_ylabel("Predicted Value (continuous)")
ax.set_title(f"Linear Regression: Actual vs Predicted Survival\nRMSE = {rmse:.4f}")
ax.legend()
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/1_linear_regression_actual_vs_predicted.png", dpi=150)
plt.close()

# --- Chart 2: Confusion Matrix (Logistic Regression) ---
fig, ax = plt.subplots(figsize=(6, 5))
cm = confusion_matrix(y_test_c, y_pred_c)
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False,
            xticklabels=["Died", "Survived"], yticklabels=["Died", "Survived"], ax=ax)
ax.set_xlabel("Predicted")
ax.set_ylabel("Actual")
ax.set_title(f"Logistic Regression: Confusion Matrix\nAccuracy = {acc*100:.2f}%")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/2_logistic_regression_confusion_matrix.png", dpi=150)
plt.close()

# --- Chart 3: Feature Importance (Logistic Regression coefficients) ---
fig, ax = plt.subplots(figsize=(7, 5))
coef_sorted = coef_df.sort_values("Coefficient")
colors = ["#C44E52" if c < 0 else "#55A868" for c in coef_sorted["Coefficient"]]
ax.barh(coef_sorted["Feature"], coef_sorted["Coefficient"], color=colors)
ax.axvline(0, color="black", linewidth=0.8)
ax.set_xlabel("Coefficient (log-odds impact on survival)")
ax.set_title("Logistic Regression: Feature Importance")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/3_feature_importance.png", dpi=150)
plt.close()

# --- Chart 4: Survival Rate by Sex and Class (exploratory context) ---
fig, ax = plt.subplots(figsize=(7, 5))
plot_df = df.copy()
sns.barplot(data=plot_df, x="Pclass", y="Survived", hue="Sex", ax=ax, palette="Set2")
ax.set_xlabel("Passenger Class")
ax.set_ylabel("Survival Rate")
ax.set_title("Survival Rate by Class and Sex")
plt.tight_layout()
plt.savefig(f"{OUT_DIR}/4_survival_rate_by_class_sex.png", dpi=150)
plt.close()

print("\nSaved 4 charts to", OUT_DIR)
